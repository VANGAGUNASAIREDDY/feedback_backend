package com.sdp.FeedBackManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedBackManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
